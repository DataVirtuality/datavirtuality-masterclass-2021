select 
	*
FROM 
	(call "file_xml".getFiles('data01.json')) f;;


select 
	to_chars(f.file, 'UTF-8'),
	jsontoxml('root', f.file)
FROM 
	(call "file_xml".getFiles('\data01.json')) f;;


SELECT 
	"xmlTable.idColumn",
	"xmlTable.firstelem",
	"xmlTable.secondelem",
	"xmlTable.thirdelem"
FROM 
	(call "file_xml".getFiles('\data01.json')) f,
	XMLTABLE(XMLNAMESPACES( 'http://www.w3.org/2001/XMLSchema-instance' as "xsi" ),'/root/included' PASSING JSONTOXML('root',to_chars(f.file,'UTF-8'))
		COLUMNS 
		"idColumn" FOR ORDINALITY,
		"firstelem" STRING  PATH 'attributes[1]',
		"secondelem" STRING  PATH 'attributes[2]',
		"thirdelem" STRING  PATH 'attributes[3]'
	) "xmlTable";;


SELECT 
	"xmlTable.idColumn",
	"attr"."attributes"
FROM 
	(call "file_xml".getFiles('\data01.json')) f,
	XMLTABLE(XMLNAMESPACES( 'http://www.w3.org/2001/XMLSchema-instance' as "xsi" ),'/root/included' PASSING JSONTOXML('root',to_chars(f.file,'UTF-8'))
		COLUMNS 
		"idColumn" FOR ORDINALITY,
		"attributes" XML PATH '.'
	) "xmlTable", 
	XMLTABLE( 'attributes' PASSING "xmlTable"."attributes"
		COLUMNS 
		"attributes" STRING PATH '.'
	) "attr";;


SELECT 
	"xmlTable.idColumn",
	"xmlTable.attributes",
	array_get("xmlTable.attributes", 1) as "firstelem",
	array_get("xmlTable.attributes", 2) as "secondelem",
	array_get("xmlTable.attributes", 3) as "thirdelem"
FROM 
		(call "file_xml".getFiles('\data01.json')) f,
	XMLTABLE(XMLNAMESPACES( 'http://www.w3.org/2001/XMLSchema-instance' as "xsi" ),'/root/included' PASSING JSONTOXML('root',to_chars(f.file,'UTF-8'))
		COLUMNS 
		"idColumn" FOR ORDINALITY,
		"type" STRING  PATH 'type',
		"id" STRING  PATH 'id',
		"attributes" STRING[]  PATH 'attributes'
	) "xmlTable";;
	
	
-- ************************************************************
-- ************************************************************
-- ************************************************************
-- ************************************************************
select 
	*
FROM 
	(call "file_xml".getFiles('\data02.json')) f;;


select 
	to_chars(f.file, 'UTF-8'),
	jsontoxml('root', f.file)
FROM 
	(call "file_xml".getFiles('\data02.json')) f;;


SELECT 
	"xmlTable.idColumn",
	"xmlTable.firstelem",
	"xmlTable.secondelem",
	"xmlTable.thirdelem"
FROM 
	(call "file_xml".getFiles('\data02.json')) f,
	XMLTABLE(XMLNAMESPACES( 'http://www.w3.org/2001/XMLSchema-instance' as "xsi" ),'/root/included' PASSING JSONTOXML('root',to_chars(f.file,'UTF-8'))
		COLUMNS 
		"idColumn" FOR ORDINALITY,
		"firstelem" STRING  PATH 'attributes[1]',
		"secondelem" STRING  PATH 'attributes[2]',
		"thirdelem" STRING  PATH 'attributes[3]'
	) "xmlTable";;


SELECT 
	"xmlTable.idColumn",
	"attr"."attributes"
FROM 
	(call "file_xml".getFiles('\data02.json')) f,
	XMLTABLE(XMLNAMESPACES( 'http://www.w3.org/2001/XMLSchema-instance' as "xsi" ),'/root/included' PASSING JSONTOXML('root',to_chars(f.file,'UTF-8'))
		COLUMNS 
		"idColumn" FOR ORDINALITY,
		"attributes" XML PATH '.'
	) "xmlTable", 
	XMLTABLE( 'attributes' PASSING "xmlTable"."attributes"
		COLUMNS 
		"attributes" STRING PATH '.'
	) "attr";;



SELECT 
	"xmlTable.idColumn",
	"xmlTable.attributes",
	array_get("xmlTable.attributes", 1) as "firstelem",
	array_get("xmlTable.attributes", 2) as "secondelem",
	array_get("xmlTable.attributes", 3) as "thirdelem"
FROM 
		(call "file_xml".getFiles('\data02.json')) f,
	XMLTABLE(XMLNAMESPACES( 'http://www.w3.org/2001/XMLSchema-instance' as "xsi" ),'/root/included' PASSING JSONTOXML('root',to_chars(f.file,'UTF-8'))
		COLUMNS 
		"idColumn" FOR ORDINALITY,
		"type" STRING  PATH 'type',
		"id" STRING  PATH 'id',
		"attributes" STRING[]  PATH 'attributes'
	) "xmlTable";;







