https://support.datavirtuality.com/hc/en-us/articles/210854723-handle-multi-valued-XML-paths

